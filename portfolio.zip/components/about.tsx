"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"

export function About() {
  const textRef = useRef<HTMLDivElement>(null)
  const imageRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            if (entry.target === textRef.current) {
              entry.target.classList.add("animate-fade-in-right")
            } else if (entry.target === imageRef.current) {
              entry.target.classList.add("animate-fade-in-left")
            }
          }
        })
      },
      { threshold: 0.1 },
    )

    if (textRef.current) observer.observe(textRef.current)
    if (imageRef.current) observer.observe(imageRef.current)

    return () => {
      if (textRef.current) observer.unobserve(textRef.current)
      if (imageRef.current) observer.unobserve(imageRef.current)
    }
  }, [])

  return (
    <section id="about" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-purple-500/5"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgdmlld0JveD0iMCAwIDYwIDYwIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMzYjgyZjYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0djZoNnYtNmgtNnptNiA2djZoLTZ2LTZoNnptLTYtMTJ2NmgtNnYtNmg2em0tNiAwdjZoLTZ2LTZoNnptMTIgMHY2aDZWMjhoLTZ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-30"></div>
      <div className="container px-4 md:px-6 relative">
        <div className="flex flex-col md:flex-row gap-12 items-center">
          <div ref={imageRef} className="md:w-1/2 flex justify-center opacity-0">
            <div className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-primary shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-purple-500/20 z-10"></div>
              <Image src="/placeholder.svg?height=256&width=256" alt="Profile" fill className="object-cover" priority />
            </div>
          </div>
          <div ref={textRef} className="md:w-1/2 space-y-6 opacity-0">
            <h2 className="gradient-text inline-block">About Me</h2>
            <p className="text-muted-foreground text-lg">
              Hello! I'm a passionate developer with a strong focus on creating intuitive and efficient web
              applications. With several years of experience in the field, I've developed a deep understanding of modern
              web technologies and best practices.
            </p>
            <p className="text-muted-foreground text-lg">
              My journey in tech began when I was in college, where I discovered my passion for coding. Since then, I've
              worked on various projects, from small business websites to complex enterprise applications.
            </p>
            <p className="text-muted-foreground text-lg">
              When I'm not coding, you can find me hiking, reading, or experimenting with new technologies.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
