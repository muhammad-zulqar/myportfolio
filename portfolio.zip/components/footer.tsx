import Link from "next/link"
import { Github, Linkedin, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t py-8 md:py-10">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
          © {new Date().getFullYear()} Your Name. All rights reserved.
        </p>

        <div className="flex gap-6">
          <Link href="#" target="_blank" rel="noopener noreferrer" aria-label="Github">
            <Github className="h-5 w-5 text-muted-foreground social-icon" />
          </Link>
          <Link href="#" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
            <Twitter className="h-5 w-5 text-muted-foreground social-icon" />
          </Link>
          <Link href="#" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
            <Linkedin className="h-5 w-5 text-muted-foreground social-icon" />
          </Link>
        </div>
      </div>
    </footer>
  )
}
