"use client"

import { useEffect, useRef } from "react"
import { Database, Globe, Layout, Server, Smartphone, Terminal } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export function Skills() {
  const titleRef = useRef<HTMLDivElement>(null)
  const skillsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (titleRef.current) observer.observe(titleRef.current)
    if (skillsRef.current) observer.observe(skillsRef.current)

    return () => {
      if (titleRef.current) observer.unobserve(titleRef.current)
      if (skillsRef.current) observer.unobserve(skillsRef.current)
    }
  }, [])

  const skills = [
    {
      category: "Frontend",
      icon: <Layout className="h-8 w-8 text-primary skill-icon" />,
      items: ["HTML", "CSS", "JavaScript", "React", "Next.js", "Tailwind CSS"],
    },
    {
      category: "Backend",
      icon: <Server className="h-8 w-8 text-primary skill-icon" />,
      items: ["Node.js", "Express", "Python", "Django", "PHP"],
    },
    {
      category: "Database",
      icon: <Database className="h-8 w-8 text-primary skill-icon" />,
      items: ["MongoDB", "MySQL", "PostgreSQL", "Firebase"],
    },
    {
      category: "Mobile",
      icon: <Smartphone className="h-8 w-8 text-primary skill-icon" />,
      items: ["React Native", "Flutter", "Swift"],
    },
    {
      category: "DevOps",
      icon: <Terminal className="h-8 w-8 text-primary skill-icon" />,
      items: ["Git", "Docker", "CI/CD", "AWS", "Vercel"],
    },
    {
      category: "Other",
      icon: <Globe className="h-8 w-8 text-primary skill-icon" />,
      items: ["SEO", "UI/UX Design", "Agile", "Scrum"],
    },
  ]

  return (
    <section id="skills" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-tl from-primary/5 via-transparent to-purple-500/5"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4MCIgaGVpZ2h0PSI4MCIgdmlld0JveD0iMCAwIDgwIDgwIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMzYjgyZjYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iMyIvPjwvZz48L2c+PC9zdmc+')] opacity-70"></div>
      <div className="container px-4 md:px-6 relative">
        <div ref={titleRef} className="text-center mb-12 opacity-0">
          <h2 className="gradient-text inline-block">My Skills</h2>
          <p className="text-muted-foreground mt-4 text-lg">Here are some of the technologies and tools I work with</p>
        </div>

        <div ref={skillsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 opacity-0">
          {skills.map((skill, index) => (
            <Card
              key={skill.category}
              className="overflow-hidden border border-border/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  {skill.icon}
                  <h3 className="text-xl font-semibold">{skill.category}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {skill.items.map((item) => (
                    <span
                      key={item}
                      className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm transition-all duration-300 hover:bg-primary hover:text-white"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
