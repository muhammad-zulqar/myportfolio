"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Download } from "lucide-react"
import Link from "next/link"
import { AnimatedBackground } from "./animated-background"

export function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (heroRef.current) {
      observer.observe(heroRef.current)
    }

    return () => {
      if (heroRef.current) {
        observer.unobserve(heroRef.current)
      }
    }
  }, [])

  return (
    <section id="home" className="py-24 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-purple-500/5 to-primary/5"></div>
      <div className="absolute inset-0 hero-pattern opacity-5"></div>
      <div className="relative">
        <AnimatedBackground density={30} color="rgba(59, 130, 246, 0.3)" />
      </div>
      <div className="container px-4 md:px-6 relative">
        <div ref={heroRef} className="flex flex-col items-center gap-6 text-center opacity-0">
          <div className="space-y-4">
            <div className="relative inline-block">
              <div className="absolute -inset-1 rounded-lg bg-gradient-to-r from-primary via-purple-500 to-primary opacity-30 blur-xl"></div>
              <h1 className="relative tracking-tighter">
                Hi, I'm <span className="gradient-text">Your Name</span>
              </h1>
            </div>
            <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
              A passionate developer specializing in web development and creating beautiful user experiences.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild size="lg" className="rounded-full shadow-lg hover:shadow-primary/20">
              <Link href="#contact">
                Contact Me <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button variant="outline" size="lg" className="rounded-full shadow-md hover:shadow-lg">
              Download CV <Download className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
